	file >> re_bid >> re_bname;
					file >> re_aname >> re_day;
					file >> re_month >> re_year;
					file >> re_hour >> re_min;
					file >> re_sec;

					file2 >> count1 >> re_name1;
					file2 >> re_bid1 >> re_bname1;
					file2 >> re_aname1 >> re_day1;
					file2 >> re_month1 >> re_year1;
					file2 >> re_hour1 >> re_min1;
					file2 >> re_sec1 >> text;